// product-detail.component.ts
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MatCardModule } from '@angular/material/card';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';

import { ProductService } from '../../../../core/services/product.service';
import { ActivatedRoute } from '@angular/router';
import { Product } from '../../models/product.model';

@Component({
  standalone: true,
  imports: [
    CommonModule,
    MatCardModule,
    MatToolbarModule,
    MatButtonModule
  ],
  templateUrl: './product-detail.component.html',
  styleUrls: ['./product-detail.component.scss'],
  template: `
    <mat-card *ngIf="product">
      <img mat-card-image [src]="product.image">
      <mat-card-title>{{ product.name }}</mat-card-title>
      <mat-card-content>
        <p>Preço: R$ {{ product.price }}</p>
      </mat-card-content>
    </mat-card>
  `
})
export class ProductDetailComponent implements OnInit {

  product!: Product;

  constructor(
    private service: ProductService,
    private route: ActivatedRoute
  ) {}

  ngOnInit() {
    const id = this.route.snapshot.params['id'];
    this.service.getById(id).subscribe(res => this.product = res);
  }
}