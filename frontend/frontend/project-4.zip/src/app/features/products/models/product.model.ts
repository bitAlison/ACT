// models/product.model.ts
export interface Product {
  id: number;
  name: string;
  price: number;
  image: string;
}